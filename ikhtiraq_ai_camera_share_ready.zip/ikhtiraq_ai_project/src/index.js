const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
});

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/api/chat") {
      if (request.method !== "POST") return json({ error: "Method not allowed" }, 405);
      if (!env.OPENAI_API_KEY) return json({ error: "مفتاح الذكاء الاصطناعي غير مضبوط في Cloudflare بعد." }, 503);

      let body;
      try {
        const raw = await request.text();
        if (raw.length > 25000) return json({ error: "الطلب كبير جداً." }, 413);
        body = JSON.parse(raw);
      } catch {
        return json({ error: "طلب غير صالح." }, 400);
      }

      const messages = body?.messages;
      if (!Array.isArray(messages) || messages.length < 1 || messages.length > 12) {
        return json({ error: "سجل المحادثة غير صالح." }, 400);
      }
      const safeMessages = [];
      for (const item of messages) {
        if (!item || !["user", "assistant"].includes(item.role) || typeof item.content !== "string" || !item.content.trim() || item.content.length > 3000) {
          return json({ error: "إحدى الرسائل غير صالحة أو طويلة جداً." }, 400);
        }
        safeMessages.push({ role: item.role, content: item.content.trim() });
      }
      if (safeMessages[safeMessages.length - 1].role !== "user") {
        return json({ error: "يجب أن تنتهي المحادثة برسالة من المستخدم." }, 400);
      }

      try {
        const upstream = await fetch("https://api.openai.com/v1/responses", {
          method: "POST",
          headers: {
            "authorization": `Bearer ${env.OPENAI_API_KEY}`,
            "content-type": "application/json"
          },
          body: JSON.stringify({
            model: "gpt-5.4-mini",
            instructions: "You are IKHTIRAQ AI, a helpful bilingual assistant. Reply in the same language as the user, preferably Iraqi Arabic when the user writes in Iraqi Arabic. Help with cybersecurity defensively, programming, and technology. Give clear practical explanations. For cybersecurity, focus on authorized, defensive learning and refuse instructions that facilitate unauthorized access, credential theft, malware, or harm. Never ask users to share passwords, API keys, or private secrets.",
            input: safeMessages,
            max_output_tokens: 900,
            store: false
          })
        });
        const result = await upstream.json();
        if (!upstream.ok) {
          const message = result?.error?.message || "OpenAI API request failed";
          return json({ error: message }, upstream.status === 429 ? 429 : 502);
        }
        const reply = (result.output || [])
          .filter(item => item.type === "message")
          .flatMap(item => item.content || [])
          .filter(part => part.type === "output_text")
          .map(part => part.text)
          .join("\n")
          .trim();
        if (!reply) return json({ error: "لم يرجع النموذج نصاً. حاول مرة ثانية." }, 502);
        return json({ reply });
      } catch (error) {
        return json({ error: "تعذر الاتصال بخدمة الذكاء الاصطناعي. حاول لاحقاً." }, 502);
      }
    }

    return env.ASSETS.fetch(request);
  }
};
