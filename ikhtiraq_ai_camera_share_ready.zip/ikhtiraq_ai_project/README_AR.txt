IKHTIRAQ AI — حزمة الموقع الكاملة

مهم: الواجهة جاهزة، لكن المحادثة الحقيقية لا تعمل قبل وضع مفتاح OpenAI API كسِرّ داخل Cloudflare ونشر Worker كامل.

الملفات:
- public/index.html : واجهة الموقع مع أدواته السابقة، اختصار الروابط، حسابات التواصل، ونافذة IKHTIRAQ AI.
- src/index.js : خادم Cloudflare Worker الذي يتصل بـ OpenAI Responses API ويحفظ المفتاح في الخادم فقط.
- wrangler.jsonc : إعدادات نشر الأصول والـ API.

خطوات النشر الموصى بها:
1) أنشئ مشروعاً محلياً/Cloudflare Workers جديداً من هذا المجلد باستخدام Wrangler، أو ارفع المشروع عبر Git إلى Cloudflare Workers Builds.
2) في Cloudflare افتح Worker > Settings > Variables and Secrets > Add > Secret.
3) اسم السر: OPENAI_API_KEY
4) القيمة: مفتاح API الذي تنشئه من منصة OpenAI. لا تضع المفتاح في HTML ولا ترسله في المحادثة.
5) احفظ السر ثم انشر Worker.
6) افتح رابط workers.dev واختبر زر IKHTIRAQ AI.

ملاحظة: مفتاح OpenAI API والفوترة منفصلان عن اشتراك ChatGPT. استخدام الواجهة قد يستهلك رصيد API بحسب الاستخدام. فعّل حدود الإنفاق/الاستخدام في منصة OpenAI، وأضف Cloudflare Rate Limiting على المسار /api/chat قبل مشاركة الموقع على نطاق واسع.


ميزة رابط الكاميرا: تفتح الكاميرا فقط بعد موافقة صاحب الجهاز، ويلتقط الصورة يدوياً ثم ينزّلها. لا يوجد التقاط خفي ولا رفع تلقائي للصور.
